
TODO: maxUnavailable has been made to 0 in rolling strategy, otherwise helm does not wait with --wait option.  Change it later.

Sequence:
* Kernel services do not depend on each other to boot up.  They can start in any order. 
