Some modifications have been made to the original Kibana code:

* Ingress has been replaced by a simpler one.  
* `test`, `examples`, Makefile removed.
