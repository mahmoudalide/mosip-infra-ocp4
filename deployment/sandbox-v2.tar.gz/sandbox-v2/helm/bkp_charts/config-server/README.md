We are using spring cloud server docker available at Docker Hub: hyness/spring-cloud-config-server

Config server Helm chart assumes that git repo with properties exists and is mounted on NFS. 



