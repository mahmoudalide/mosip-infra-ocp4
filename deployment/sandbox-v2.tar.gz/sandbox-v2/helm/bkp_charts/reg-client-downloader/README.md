This Chart is there for downloading the latest reg-client as per the version passed to the docker image and can also be used to upgrade the client.
