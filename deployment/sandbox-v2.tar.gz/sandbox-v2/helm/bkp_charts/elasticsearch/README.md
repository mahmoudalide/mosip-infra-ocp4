Some modifications have been made to the original Elasticsearch code:

* Ingress has been replaced by a simpler one.  
* `test` and `examples` dir removed.
* Persistence disabled for now.
