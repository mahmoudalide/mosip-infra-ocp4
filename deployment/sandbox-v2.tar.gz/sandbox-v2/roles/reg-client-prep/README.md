The Role is to created a directory in NFS and than copy the necesary metadata.xml and mosip certificate into that dorectory so that it can be used by the reg-client-downloader to create reg-client zip.

