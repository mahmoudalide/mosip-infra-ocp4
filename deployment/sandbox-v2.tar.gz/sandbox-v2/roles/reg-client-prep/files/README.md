The zip file here contains temp keys for reg client to work with sandbox.  Change these keys and corresponding keys for a given deployment.
