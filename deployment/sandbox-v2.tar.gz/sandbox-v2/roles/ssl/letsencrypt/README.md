Role to create letsencrypt certificate for the domain for https connection.  It's assumed that nginx server is up and running with port 80 opened up before these scripts are called.
