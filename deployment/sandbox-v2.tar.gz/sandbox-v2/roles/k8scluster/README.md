All roles related to installation of Kubernetes cluster.

The Ansible code here is based on 

https://github.com/kairen/kubeadm-ansible

There are minor modifications done to integrated with this system.



