Postgres init run only once.  A lock file called 'init.lock' is created in postgres persistence folder on successful init.  If you want to initialized DB again delete this file.
