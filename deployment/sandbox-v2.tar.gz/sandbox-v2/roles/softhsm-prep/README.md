The tasks here prepare the necessary directories for softhsm is intallation. 

 Softhsm module is NOT installed here, but is installed by the Kernel Helm charts.  This prep is necessary before we run the Kube scripts.
