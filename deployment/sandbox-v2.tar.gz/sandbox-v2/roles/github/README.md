This role is created to clone private repositories with username and password.  The password is not stored anywhere on the disk.
