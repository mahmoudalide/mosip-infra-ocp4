This roles fills some default values in Partner Management Service tables that are needed in the sandbox.  The PMS db tables are updated directly using sql.  The same is better achieved using PMS APIs, but that would make automation complex, so adding values directly.

1. ABIS:  For proxy ABIS, the same should be added as a partner along with appropriate policy.  



TODO: user names etc are hardcoded in the sql scripts.  Make them configurable.
